export interface Subject {
  id: string;
  name: string;
  chapters: number;
  examDate?: string;
  priority: 'low' | 'medium' | 'high';
  color: string;
  completed: number;
}

export interface StudyHours {
  weekdays: number;
  weekends: number;
}

export interface StudySession {
  id: string;
  subject: string;
  duration: number;
  chapters: string;
  completed: boolean;
}

export interface DayPlan {
  day: string;
  date: string;
  sessions: StudySession[];
  totalHours: number;
}

export interface StudyPlan {
  [key: string]: DayPlan;
}

export interface StudentData {
  subjects: Subject[];
  studyHours: StudyHours;
  preferences: {
    noRepeats: boolean;
    preferredTimes: string[];
    breakDuration: number;
  };
  startDate: string;
}

export interface CoachMessage {
  type: 'info' | 'success' | 'warning' | 'motivational';
  message: string;
  icon?: string;
}