import React, { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { InputForm } from './components/InputForm';
import { StudyPlanDisplay } from './components/StudyPlanDisplay';
import { StudyPlannerEngine } from './utils/studyPlanner';
import { StudentData, StudyPlan } from './types';

type AppState = 'welcome' | 'input' | 'plan';

function App() {
  const [currentState, setCurrentState] = useState<AppState>('welcome');
  const [studentData, setStudentData] = useState<StudentData | null>(null);
  const [studyPlan, setStudyPlan] = useState<StudyPlan | null>(null);
  const [motivationalMessage, setMotivationalMessage] = useState<string>('');

  const planner = new StudyPlannerEngine();

  const handleGetStarted = () => {
    setCurrentState('input');
  };

  const handleFormSubmit = (data: StudentData) => {
    setStudentData(data);
    const plan = planner.generateStudyPlan(data);
    const message = planner.generateMotivationalMessage(data, plan);
    
    setStudyPlan(plan);
    setMotivationalMessage(message);
    setCurrentState('plan');
  };

  const handleReset = () => {
    setCurrentState('welcome');
    setStudentData(null);
    setStudyPlan(null);
    setMotivationalMessage('');
  };

  const handleBackToWelcome = () => {
    setCurrentState('welcome');
  };

  const handleUpdatePlan = (updatedPlan: StudyPlan) => {
    setStudyPlan(updatedPlan);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {currentState === 'welcome' && (
        <WelcomeScreen onGetStarted={handleGetStarted} />
      )}
      
      {currentState === 'input' && (
        <InputForm 
          onSubmit={handleFormSubmit} 
          onBack={handleBackToWelcome}
        />
      )}
      
      {currentState === 'plan' && studentData && studyPlan && (
        <StudyPlanDisplay
          plan={studyPlan}
          studentData={studentData}
          motivationalMessage={motivationalMessage}
          onReset={handleReset}
          onUpdatePlan={handleUpdatePlan}
        />
      )}
    </div>
  );
}

export default App;