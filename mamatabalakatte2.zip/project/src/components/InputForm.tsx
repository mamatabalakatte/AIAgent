import React, { useState } from 'react';
import { Plus, X, Calendar, Clock, BookOpen, Target } from 'lucide-react';
import { Subject, StudyHours, StudentData } from '../types';

interface InputFormProps {
  onSubmit: (data: StudentData) => void;
  onBack?: () => void;
}

const SUBJECT_COLORS = [
  '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
  '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1'
];

export const InputForm: React.FC<InputFormProps> = ({ onSubmit, onBack }) => {
  const [step, setStep] = useState(1);
  const [subjects, setSubjects] = useState<Subject[]>([
    { id: '1', name: '', chapters: 0, priority: 'medium', color: SUBJECT_COLORS[0], completed: 0 }
  ]);
  const [studyHours, setStudyHours] = useState<StudyHours>({ weekdays: 3, weekends: 5 });
  const [preferences, setPreferences] = useState({
    noRepeats: true,
    preferredTimes: ['morning'],
    breakDuration: 15
  });

  const addSubject = () => {
    const newSubject: Subject = {
      id: Date.now().toString(),
      name: '',
      chapters: 0,
      priority: 'medium',
      color: SUBJECT_COLORS[subjects.length % SUBJECT_COLORS.length],
      completed: 0
    };
    setSubjects([...subjects, newSubject]);
  };

  const removeSubject = (id: string) => {
    if (subjects.length > 1) {
      setSubjects(subjects.filter(s => s.id !== id));
    }
  };

  const updateSubject = (id: string, field: keyof Subject, value: any) => {
    setSubjects(subjects.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const handleSubmit = () => {
    const validSubjects = subjects.filter(s => s.name.trim() && s.chapters > 0);
    
    if (validSubjects.length === 0) {
      alert('Please add at least one subject with chapters');
      return;
    }

    const studentData: StudentData = {
      subjects: validSubjects,
      studyHours,
      preferences,
      startDate: new Date().toISOString().split('T')[0]
    };

    onSubmit(studentData);
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return subjects.some(s => s.name.trim() && s.chapters > 0);
      case 2:
        return studyHours.weekdays > 0 && studyHours.weekends > 0;
      default:
        return true;
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-2xl shadow-xl p-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-gray-800">
              {step === 1 && "📚 Tell me about your subjects"}
              {step === 2 && "⏰ How much time can you study?"}
              {step === 3 && "⚙️ Set your preferences"}
            </h2>
            <span className="text-sm text-gray-500">Step {step} of 3</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            />
          </div>
        </div>

        {/* Step 1: Subjects */}
        {step === 1 && (
          <div className="space-y-6">
            <p className="text-gray-600 mb-6">
              Add your subjects, number of chapters, and any upcoming exam dates. I'll prioritize accordingly!
            </p>
            
            {subjects.map((subject, index) => (
              <div key={subject.id} className="bg-gray-50 p-6 rounded-xl border-2 border-gray-200 hover:border-blue-300 transition-colors">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: subject.color }}
                    />
                    <span className="font-medium text-gray-700">Subject {index + 1}</span>
                  </div>
                  {subjects.length > 1 && (
                    <button
                      onClick={() => removeSubject(subject.id)}
                      className="text-red-500 hover:text-red-700 transition-colors"
                    >
                      <X size={20} />
                    </button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <BookOpen size={16} className="inline mr-1" />
                      Subject Name
                    </label>
                    <input
                      type="text"
                      value={subject.name}
                      onChange={(e) => updateSubject(subject.id, 'name', e.target.value)}
                      placeholder="e.g., Mathematics"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      📖 Chapters/Topics
                    </label>
                    <input
                      type="number"
                      value={subject.chapters || ''}
                      onChange={(e) => updateSubject(subject.id, 'chapters', parseInt(e.target.value) || 0)}
                      placeholder="10"
                      min="1"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Target size={16} className="inline mr-1" />
                      Priority
                    </label>
                    <select
                      value={subject.priority}
                      onChange={(e) => updateSubject(subject.id, 'priority', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Calendar size={16} className="inline mr-1" />
                      Exam Date (optional)
                    </label>
                    <input
                      type="date"
                      value={subject.examDate || ''}
                      onChange={(e) => updateSubject(subject.id, 'examDate', e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
            ))}
            
            <button
              onClick={addSubject}
              className="w-full p-4 border-2 border-dashed border-blue-300 rounded-xl text-blue-600 hover:bg-blue-50 transition-colors flex items-center justify-center space-x-2"
            >
              <Plus size={20} />
              <span>Add Another Subject</span>
            </button>
          </div>
        )}

        {/* Step 2: Study Hours */}
        {step === 2 && (
          <div className="space-y-6">
            <p className="text-gray-600 mb-6">
              Be realistic about your available time. Quality over quantity always wins!
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Clock className="text-blue-600" size={24} />
                  <h3 className="text-lg font-semibold text-gray-800">Weekdays</h3>
                </div>
                <p className="text-gray-600 mb-4">Monday to Friday</p>
                <div className="flex items-center space-x-3">
                  <input
                    type="range"
                    min="0.5"
                    max="8"
                    step="0.5"
                    value={studyHours.weekdays}
                    onChange={(e) => setStudyHours({...studyHours, weekdays: parseFloat(e.target.value)})}
                    className="flex-1"
                  />
                  <span className="text-xl font-bold text-blue-600 min-w-[3rem]">
                    {studyHours.weekdays}h
                  </span>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border border-green-200">
                <div className="flex items-center space-x-3 mb-4">
                  <Clock className="text-green-600" size={24} />
                  <h3 className="text-lg font-semibold text-gray-800">Weekends</h3>
                </div>
                <p className="text-gray-600 mb-4">Saturday & Sunday</p>
                <div className="flex items-center space-x-3">
                  <input
                    type="range"
                    min="0.5"
                    max="12"
                    step="0.5"
                    value={studyHours.weekends}
                    onChange={(e) => setStudyHours({...studyHours, weekends: parseFloat(e.target.value)})}
                    className="flex-1"
                  />
                  <span className="text-xl font-bold text-green-600 min-w-[3rem]">
                    {studyHours.weekends}h
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <p className="text-yellow-800">
                <strong>💡 Pro Tip:</strong> Your weekly total will be{' '}
                <span className="font-bold">
                  {(studyHours.weekdays * 5 + studyHours.weekends * 2).toFixed(1)} hours
                </span>
                . This is a solid foundation for success!
              </p>
            </div>
          </div>
        )}

        {/* Step 3: Preferences */}
        {step === 3 && (
          <div className="space-y-6">
            <p className="text-gray-600 mb-6">
              Let's customize your study plan to match your learning style!
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div>
                  <h3 className="font-medium text-gray-800">Avoid Same Subject Repetition</h3>
                  <p className="text-sm text-gray-600">Don't study the same subject on consecutive days</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preferences.noRepeats}
                    onChange={(e) => setPreferences({...preferences, noRepeats: e.target.checked})}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-xl">
                <h3 className="font-medium text-gray-800 mb-3">Break Duration (minutes)</h3>
                <div className="flex items-center space-x-3">
                  <input
                    type="range"
                    min="5"
                    max="30"
                    step="5"
                    value={preferences.breakDuration}
                    onChange={(e) => setPreferences({...preferences, breakDuration: parseInt(e.target.value)})}
                    className="flex-1"
                  />
                  <span className="text-lg font-medium text-gray-700 min-w-[3rem]">
                    {preferences.breakDuration}min
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
          <button
            onClick={() => step > 1 ? setStep(step - 1) : onBack?.()}
            className="px-6 py-3 text-gray-600 hover:text-gray-800 transition-colors flex items-center space-x-2"
          >
            <span>← Back</span>
          </button>
          
          <div className="flex space-x-3">
            {step < 3 ? (
              <button
                onClick={() => setStep(step + 1)}
                disabled={!canProceed()}
                className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105"
              >
                Continue →
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={!canProceed()}
                className="px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 text-white rounded-lg hover:from-green-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-105"
              >
                Create My Plan 🚀
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};