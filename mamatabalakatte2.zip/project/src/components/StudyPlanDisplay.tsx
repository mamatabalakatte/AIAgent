import React, { useState } from 'react';
import { Calendar, Clock, BookOpen, CheckCircle, Target, TrendingUp, Award, RotateCcw } from 'lucide-react';
import { StudyPlan, DayPlan, StudySession, StudentData, CoachMessage } from '../types';

interface StudyPlanDisplayProps {
  plan: StudyPlan;
  studentData: StudentData;
  motivationalMessage: string;
  onReset: () => void;
  onUpdatePlan: (updatedPlan: StudyPlan) => void;
}

export const StudyPlanDisplay: React.FC<StudyPlanDisplayProps> = ({
  plan,
  studentData,
  motivationalMessage,
  onReset,
  onUpdatePlan
}) => {
  const [completedSessions, setCompletedSessions] = useState<Set<string>>(new Set());
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  const toggleSession = (sessionId: string) => {
    const newCompleted = new Set(completedSessions);
    if (newCompleted.has(sessionId)) {
      newCompleted.delete(sessionId);
    } else {
      newCompleted.add(sessionId);
    }
    setCompletedSessions(newCompleted);
  };

  const calculateProgress = () => {
    const totalSessions = Object.values(plan).reduce((sum, day) => sum + day.sessions.length, 0);
    const completedCount = completedSessions.size;
    return totalSessions > 0 ? (completedCount / totalSessions) * 100 : 0;
  };

  const getTotalHours = () => {
    return Object.values(plan).reduce((sum, day) => sum + day.totalHours, 0);
  };

  const getDayColor = (day: string) => {
    const colors = {
      monday: 'from-blue-500 to-blue-600',
      tuesday: 'from-green-500 to-green-600',
      wednesday: 'from-yellow-500 to-yellow-600',
      thursday: 'from-red-500 to-red-600',
      friday: 'from-purple-500 to-purple-600',
      saturday: 'from-indigo-500 to-indigo-600',
      sunday: 'from-pink-500 to-pink-600'
    };
    return colors[day.toLowerCase() as keyof typeof colors] || 'from-gray-500 to-gray-600';
  };

  const getSubjectColor = (subjectName: string) => {
    const subject = studentData.subjects.find(s => s.name === subjectName);
    return subject?.color || '#6B7280';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const planDays = Object.entries(plan).map(([dayKey, dayPlan]) => ({
    key: dayKey,
    ...dayPlan
  }));

  const progress = calculateProgress();
  const totalHours = getTotalHours();

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <Award className="text-yellow-500" size={32} />
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Your Personalized Study Plan
          </h1>
        </div>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          {motivationalMessage}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
          <div className="flex items-center space-x-3">
            <BookOpen className="text-blue-600" size={24} />
            <div>
              <p className="text-sm text-blue-600 font-medium">Total Subjects</p>
              <p className="text-2xl font-bold text-blue-800">{studentData.subjects.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
          <div className="flex items-center space-x-3">
            <Clock className="text-green-600" size={24} />
            <div>
              <p className="text-sm text-green-600 font-medium">Total Hours</p>
              <p className="text-2xl font-bold text-green-800">{totalHours.toFixed(1)}h</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
          <div className="flex items-center space-x-3">
            <TrendingUp className="text-purple-600" size={24} />
            <div>
              <p className="text-sm text-purple-600 font-medium">Progress</p>
              <p className="text-2xl font-bold text-purple-800">{progress.toFixed(0)}%</p>
            </div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl border border-orange-200">
          <div className="flex items-center space-x-3">
            <Target className="text-orange-600" size={24} />
            <div>
              <p className="text-sm text-orange-600 font-medium">Completed</p>
              <p className="text-2xl font-bold text-orange-800">
                {completedSessions.size}/{Object.values(plan).reduce((sum, day) => sum + day.sessions.length, 0)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Weekly Progress</h3>
          <span className="text-sm text-gray-500">{progress.toFixed(1)}% Complete</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div 
            className="bg-gradient-to-r from-green-400 to-blue-500 h-4 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Weekly Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-7 gap-4">
        {planDays.map((dayPlan) => (
          <div key={dayPlan.key} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className={`bg-gradient-to-r ${getDayColor(dayPlan.day)} p-4 text-white`}>
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg">{dayPlan.day}</h3>
                  <p className="text-sm opacity-90">{formatDate(dayPlan.date)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm opacity-90">Total</p>
                  <p className="font-bold">{dayPlan.totalHours.toFixed(1)}h</p>
                </div>
              </div>
            </div>
            
            <div className="p-4 space-y-3">
              {dayPlan.sessions.length === 0 ? (
                <p className="text-gray-500 text-center py-4">Rest Day 😊</p>
              ) : (
                dayPlan.sessions.map((session) => (
                  <div
                    key={session.id}
                    className={`p-3 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                      completedSessions.has(session.id)
                        ? 'bg-green-50 border-green-300'
                        : 'bg-gray-50 border-gray-200 hover:border-blue-300'
                    }`}
                    onClick={() => toggleSession(session.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: getSubjectColor(session.subject) }}
                        />
                        <span className="font-medium text-sm">{session.subject}</span>
                      </div>
                      <CheckCircle
                        size={16}
                        className={`transition-colors ${
                          completedSessions.has(session.id)
                            ? 'text-green-500'
                            : 'text-gray-300'
                        }`}
                      />
                    </div>
                    <div className="mt-2 text-xs text-gray-600">
                      <p>{session.chapters}</p>
                      <p>{session.duration.toFixed(1)} hours</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Study Tips */}
      <div className="bg-gradient-to-br from-yellow-50 to-orange-50 border border-yellow-200 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">📌 Study Tips for Success</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-sm text-gray-700">
              <strong>🍅 Pomodoro Technique:</strong> Study for 25 minutes, then take a 5-minute break
            </p>
            <p className="text-sm text-gray-700">
              <strong>📝 Active Recall:</strong> Test yourself instead of just re-reading
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-gray-700">
              <strong>🧠 Spaced Repetition:</strong> Review previous topics regularly
            </p>
            <p className="text-sm text-gray-700">
              <strong>💪 Stay Consistent:</strong> Small daily efforts beat marathon sessions
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-center space-x-4">
        <button
          onClick={onReset}
          className="px-6 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors flex items-center space-x-2"
        >
          <RotateCcw size={20} />
          <span>Create New Plan</span>
        </button>
      </div>
    </div>
  );
};