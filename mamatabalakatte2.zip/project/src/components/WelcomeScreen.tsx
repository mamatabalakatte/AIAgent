import React from 'react';
import { BookOpen, Target, Clock, TrendingUp, ArrowRight, Brain, Users, Award } from 'lucide-react';

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onGetStarted }) => {
  const features = [
    {
      icon: <Brain className="text-blue-500" size={32} />,
      title: "AI-Powered Planning",
      description: "Smart algorithms that understand your learning style and create personalized study schedules"
    },
    {
      icon: <Target className="text-green-500" size={32} />,
      title: "Priority-Based Scheduling",
      description: "Automatically prioritizes subjects based on exam dates and difficulty levels"
    },
    {
      icon: <Clock className="text-purple-500" size={32} />,
      title: "Flexible Time Management",
      description: "Adapts to your daily schedule with separate weekday and weekend planning"
    },
    {
      icon: <TrendingUp className="text-orange-500" size={32} />,
      title: "Progress Tracking",
      description: "Visual progress monitoring with motivational insights to keep you on track"
    }
  ];

  const testimonials = [
    {
      name: "Sarah M.",
      role: "Medical Student",
      quote: "This AI coach helped me organize my study schedule for 12 subjects. Passed all my exams!",
      avatar: "👩‍⚕️"
    },
    {
      name: "Alex K.",
      role: "Engineering Student",
      quote: "The priority-based scheduling saved me during finals week. Highly recommend!",
      avatar: "👨‍💻"
    },
    {
      name: "Maria L.",
      role: "High School Student",
      quote: "Finally, a study plan that actually works with my busy schedule. Love it!",
      avatar: "👩‍🎓"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="text-center space-y-8">
          {/* Logo and Title */}
          <div className="space-y-4">
            <div className="flex items-center justify-center space-x-3">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-4 rounded-full">
                <BookOpen className="text-white" size={32} />
              </div>
              <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Study Coach GPT
              </h1>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Your AI-powered study companion that creates personalized weekly study plans. 
              Smart, adaptive, and designed to maximize your learning potential.
            </p>
          </div>

          {/* CTA Button */}
          <button
            onClick={onGetStarted}
            className="inline-flex items-center space-x-3 px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-lg font-semibold rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            <span>Get Started Now</span>
            <ArrowRight size={20} />
          </button>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="flex items-center justify-center space-x-3 mb-3">
                <Users className="text-blue-500" size={24} />
                <span className="text-2xl font-bold text-gray-800">10K+</span>
              </div>
              <p className="text-gray-600">Students Helped</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="flex items-center justify-center space-x-3 mb-3">
                <Award className="text-green-500" size={24} />
                <span className="text-2xl font-bold text-gray-800">95%</span>
              </div>
              <p className="text-gray-600">Success Rate</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="flex items-center justify-center space-x-3 mb-3">
                <BookOpen className="text-purple-500" size={24} />
                <span className="text-2xl font-bold text-gray-800">50K+</span>
              </div>
              <p className="text-gray-600">Study Plans Created</p>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Why Choose Study Coach GPT?
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our advanced AI understands your unique learning needs and creates plans that actually work
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    {feature.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mt-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              What Students Say
            </h2>
            <p className="text-gray-600">
              Real feedback from students who transformed their study habits
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="text-3xl">{testimonial.avatar}</div>
                  <div>
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
                <blockquote className="text-gray-700 italic">
                  "{testimonial.quote}"
                </blockquote>
              </div>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="mt-24 text-center">
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-12 rounded-2xl text-white">
            <h2 className="text-3xl font-bold mb-4">
              Ready to Transform Your Study Habits?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of students who have improved their grades with AI-powered study planning
            </p>
            <button
              onClick={onGetStarted}
              className="inline-flex items-center space-x-3 px-8 py-4 bg-white text-blue-600 text-lg font-semibold rounded-xl hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 shadow-lg"
            >
              <span>Start Your Free Plan</span>
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};