import { Subject, StudyHours, StudyPlan, DayPlan, StudySession, StudentData } from '../types';

export class StudyPlannerEngine {
  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  private getWeekDays(startDate: string): string[] {
    const days = [];
    const start = new Date(startDate);
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      days.push({
        day: date.toLocaleDateString('en-US', { weekday: 'long' }),
        date: date.toISOString().split('T')[0]
      });
    }
    
    return days;
  }

  private calculatePriority(subject: Subject): number {
    let priority = 1;
    
    if (subject.examDate) {
      const examDate = new Date(subject.examDate);
      const today = new Date();
      const daysUntilExam = Math.ceil((examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysUntilExam <= 3) priority = 5;
      else if (daysUntilExam <= 7) priority = 4;
      else if (daysUntilExam <= 14) priority = 3;
      else priority = 2;
    }
    
    if (subject.priority === 'high') priority += 1;
    else if (subject.priority === 'low') priority -= 0.5;
    
    return priority;
  }

  private distributeStudyTime(subjects: Subject[], studyHours: StudyHours): { [key: string]: number } {
    const totalChapters = subjects.reduce((sum, subject) => sum + subject.chapters, 0);
    const weeklyHours = (studyHours.weekdays * 5) + (studyHours.weekends * 2);
    
    const distribution: { [key: string]: number } = {};
    
    subjects.forEach(subject => {
      const priorityWeight = this.calculatePriority(subject);
      const chapterWeight = subject.chapters / totalChapters;
      const baseTime = weeklyHours * chapterWeight;
      distribution[subject.id] = Math.max(1, baseTime * priorityWeight);
    });
    
    return distribution;
  }

  public generateStudyPlan(studentData: StudentData): StudyPlan {
    const weekDays = this.getWeekDays(studentData.startDate);
    const timeDistribution = this.distributeStudyTime(studentData.subjects, studentData.studyHours);
    const plan: StudyPlan = {};
    
    // Track remaining time for each subject
    const remainingTime = { ...timeDistribution };
    
    weekDays.forEach(({ day, date }, index) => {
      const isWeekend = day === 'Saturday' || day === 'Sunday';
      const availableHours = isWeekend ? studentData.studyHours.weekends : studentData.studyHours.weekdays;
      
      const dayPlan: DayPlan = {
        day,
        date,
        sessions: [],
        totalHours: 0
      };
      
      let remainingDayHours = availableHours;
      
      // Sort subjects by priority and remaining time
      const sortedSubjects = [...studentData.subjects].sort((a, b) => {
        const priorityDiff = this.calculatePriority(b) - this.calculatePriority(a);
        if (priorityDiff !== 0) return priorityDiff;
        return remainingTime[b.id] - remainingTime[a.id];
      });
      
      // Assign study sessions
      for (const subject of sortedSubjects) {
        if (remainingDayHours <= 0 || remainingTime[subject.id] <= 0) continue;
        
        const sessionDuration = Math.min(
          remainingDayHours,
          remainingTime[subject.id],
          3 // Max 3 hours per session
        );
        
        if (sessionDuration >= 0.5) { // Minimum 30 minutes
          const chaptersToStudy = Math.ceil((sessionDuration / timeDistribution[subject.id]) * subject.chapters);
          
          const session: StudySession = {
            id: this.generateId(),
            subject: subject.name,
            duration: sessionDuration,
            chapters: `${chaptersToStudy} chapter${chaptersToStudy > 1 ? 's' : ''}`,
            completed: false
          };
          
          dayPlan.sessions.push(session);
          dayPlan.totalHours += sessionDuration;
          remainingDayHours -= sessionDuration;
          remainingTime[subject.id] -= sessionDuration;
        }
      }
      
      plan[day.toLowerCase()] = dayPlan;
    });
    
    return plan;
  }

  public generateMotivationalMessage(studentData: StudentData, plan: StudyPlan): string {
    const totalHours = Object.values(plan).reduce((sum, day) => sum + day.totalHours, 0);
    const subjects = studentData.subjects.length;
    const urgentSubjects = studentData.subjects.filter(s => s.examDate && 
      new Date(s.examDate).getTime() - new Date().getTime() < 7 * 24 * 60 * 60 * 1000
    ).length;
    
    const messages = [
      `🎯 You've got ${totalHours.toFixed(1)} hours of focused study ahead. That's your path to success!`,
      `📚 ${subjects} subjects, one week, unlimited potential. Let's make it happen!`,
      `⚡ Consistency beats intensity. Your daily study routine will compound into amazing results!`,
      `🌟 Every chapter you complete brings you closer to mastering your subjects. You've got this!`,
      `🚀 This balanced plan ensures you're prepared without burning out. Smart studying wins!`
    ];
    
    if (urgentSubjects > 0) {
      messages.push(`🔥 ${urgentSubjects} exam${urgentSubjects > 1 ? 's' : ''} coming up soon - your focused preparation will pay off!`);
    }
    
    return messages[Math.floor(Math.random() * messages.length)];
  }
}